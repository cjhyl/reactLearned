import axios from "axios"
import { useInfiniteQuery } from "react-query"

async function fetchUser({ pageParam = 1 }) {
  try {
    return axios.get(`https://reqres.in/api/users?page=${pageParam}`)
  } catch (err) {
    throw new Error("用户状态同步失败")
  }
}

function LoadMore() {
  const {
    data,
    isLoading,
    isFetching,
    hasNextPage,
    fetchNextPage
  } = useInfiniteQuery("users", fetchUser, {
    getNextPageParam(current) {
      if (current.page < current.total_pages) {
        return current.page + 1
      }
    }
  })
  if (isLoading) return <div>用户状态正在加载中...</div>
  return (
    <div>
      <ul>
        {data.pages.map(page =>
          page.data.map(user => <li key={user.id}>{user.first_name}</li>)
        )}
      </ul>
      {hasNextPage && <button onClick={() => fetchNextPage()}>加载更多</button>}
      {isFetching && <div>更多状态加载中...</div>}
    </div>
  )
}

export default LoadMore
