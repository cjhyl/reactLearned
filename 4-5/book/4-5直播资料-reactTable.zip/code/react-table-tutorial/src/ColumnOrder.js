import MOCK_DADA from "./MOCK_DATA.json"
import { COLUMNS } from "./columns"
import { useTable, useColumnOrder } from "react-table"
import { useMemo } from "react"
import "./table.css"

function ColumnOrder() {
  const data = useMemo(() => MOCK_DADA, [])
  const columns = useMemo(() => COLUMNS, [])
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    footerGroups,
    setColumnOrder
  } = useTable(
    {
      columns,
      data
    },
    useColumnOrder
  )
  return (
    <>
      <button
        onClick={() =>
          setColumnOrder([
            "id",
            "first_name",
            "last_name",
            "phone",
            "country",
            "date_of_birth"
          ])
        }
      >
        更改列顺序
      </button>
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(header => (
                <th {...header.getHeaderProps()}>{header.render("Header")}</th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.map(row => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => (
                  <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                ))}
              </tr>
            )
          })}
        </tbody>
        <tfoot>
          {footerGroups.map(footerGroup => (
            <tr {...footerGroup.getFooterGroupProps()}>
              {footerGroup.headers.map(header => (
                <td {...header.getFooterProps()}>{header.render("Footer")}</td>
              ))}
            </tr>
          ))}
        </tfoot>
      </table>
    </>
  )
}

export default ColumnOrder
