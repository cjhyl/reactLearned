// BasicTable.js
import { useTable, useFilters } from "react-table"
import { COLUMNS } from "./Columns"
import MOCK_DATA from "./MOCK_DATA.json"
import { useMemo } from "react"
import ColumnFilter from "./ColumnFilter"
import "./table.css"

function ColumnFilterTable() {
  // 缓存列信息
  const columns = useMemo(() => COLUMNS, [])
  // 缓存表格数据
  const data = useMemo(() => MOCK_DATA, [])
  // 设置默认列属性
  const defaultColumn = useMemo(() => ({ Filter: ColumnFilter }), [])
  // 创建表格实例对象
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    footerGroups
  } = useTable(
    {
      columns,
      defaultColumn,
      data
    },
    useFilters
  )
  // getTableProps: 此方法负责返回 table 标记属性
  // getTableBodyProps: 此方法负责返回 tbody 标记属性
  // headerGroups: 保存表格头部信息, 数组类型, 数组中的对象对应 tr，对象中的 headers 数组对应 th
  // footerGroups: 保存表格底部信息, 数组类型, 数组中的对象对应 tr, 对象中的 headers 数组对应 th
  // rows: 保存表格主体信息, 数组类型, 数组中的对象对应 tr, 对象中的 cells 数组对应 td
  // prepare: 此方法负责懒惰的准备要渲染的行. 任何行在展示之前都需要传递给该方法用以提高性能.

  // headerGroup.getHeaderGroupProps: 此方法负责返回 thead -> tr 标记属性
  // header.getHeaderProps: 此方法负责返回 thead -> td 标记属性
  // row.getRowProps: 此方法负责返回 tbody -> tr 标记属性
  // cell.getCellProps: 此方法负责返回 tbody -> td 标记属性

  return (
    <>
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(header => (
                <th {...header.getHeaderProps()}>
                  {header.render("Header")}{" "}
                  {header.canFilter ? header.render("Filter") : null}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.map(row => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => (
                  <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                ))}
              </tr>
            )
          })}
        </tbody>
        <tfoot>
          {footerGroups.map(footerGroup => (
            <tr {...footerGroup.getFooterGroupProps()}>
              {footerGroup.headers.map(header => (
                <th {...header.getHeaderProps()}>{header.render("Footer")}</th>
              ))}
            </tr>
          ))}
        </tfoot>
      </table>
    </>
  )
}

export default ColumnFilterTable
