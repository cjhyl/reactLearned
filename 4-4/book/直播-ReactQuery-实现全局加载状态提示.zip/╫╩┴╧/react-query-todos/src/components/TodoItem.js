import RemoveTodo from "./RemoveTodo"
import TodoCompleted from "./TodoCompleted"

function TodoItem({ todo }) {
  return (
    <li className={todo.isCompleted ? "completed" : ""}>
      <div className="view">
        <TodoCompleted todo={todo} />
        <label>{todo.title}</label>
        <RemoveTodo todo={todo} />
      </div>
      <input className="edit" />
    </li>
  )
}

export default TodoItem
