import TodoItem from "./TodoItem"
import { useTodos } from "../hooks/todos"

function TodosMain() {
  const { isLoading, isError, error, data } = useTodos()
  if (isLoading) return <div>正在加载服务端默认待办事项</div>
  if (isError) return <div>{error.message}</div>
  return (
    <section className="main">
      <input className="toggle-all" type="checkbox" />
      <ul className="todo-list">
        {data && data.map(todo => <TodoItem key={todo.id} todo={todo} />)}
      </ul>
    </section>
  )
}

export default TodosMain
