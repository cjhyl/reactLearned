import axios from "axios"
import { useQuery } from "react-query"

async function fetchTodos() {
  try {
    return axios.get("/todos")
  } catch (err) {
    throw new Error("服务器端默认的待办事项获取失败")
  }
}

export function useTodos() {
  return useQuery("todos", fetchTodos)
}
