import MOCK_DADA from "./MOCK_DATA.json"
import { COLUMNS } from "./columns"
import { useTable, useFilters } from "react-table"
import { useMemo } from "react"
import "./table.css"
import ColumnFilter from "./ColumnFilter"

function ColumnFilterTable() {
  const data = useMemo(() => MOCK_DADA, [])
  const columns = useMemo(() => COLUMNS, [])
  const defaultColumn = useMemo(() => ({ Filter: ColumnFilter }), [])
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    footerGroups
  } = useTable(
    {
      columns,
      data,
      defaultColumn
    },
    useFilters
  )
  return (
    <table {...getTableProps()}>
      <thead>
        {headerGroups.map(headerGroup => (
          <tr {...headerGroup.getHeaderGroupProps()}>
            {headerGroup.headers.map(header => (
              <th {...header.getHeaderProps()}>
                {header.render("Header")}
                {header.canFilter ? header.render("Filter") : null}
              </th>
            ))}
          </tr>
        ))}
      </thead>
      <tbody {...getTableBodyProps()}>
        {rows.map(row => {
          prepareRow(row)
          return (
            <tr {...row.getRowProps()}>
              {row.cells.map(cell => (
                <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
              ))}
            </tr>
          )
        })}
      </tbody>
      <tfoot>
        {footerGroups.map(footerGroup => (
          <tr {...footerGroup.getFooterGroupProps()}>
            {footerGroup.headers.map(header => (
              <td {...header.getFooterProps()}>{header.render("Footer")}</td>
            ))}
          </tr>
        ))}
      </tfoot>
    </table>
  )
}

export default ColumnFilterTable
