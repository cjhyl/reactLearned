# [React Query](https://react-query.tanstack.com/)

## 1.  概述

React Query 使 React 应用获取，缓存，同步和更新服务端状态变得轻而易举。

1. 请求管理

   在适当时机自动向服务端发送请求以同步状态。适当时机是指当请求出错时，网络重新连接时，浏览器窗口重新获取焦点时。

   它是基于请求库上层的封装，实现了和请求相关的逻辑， 比如无限加载，失败重试，轮询，请求状态查询等。

   它不生产请求，它只是请求的搬运工。

2. 状态管理

   将服务端状态同步到客户端的内存中进行缓存，任何组件都可以从缓存中获取状态，从而实现全局状态共享。

下载：`yarn add react-query@3.16.0`

## 2. 状态模拟

1. 本地安装状态模拟工具 `yarn add json-server`

2. 创建 db.json 本地状态库

   ```json
   {
     "todos": [
       {
         "id": 1,
         "title": "吃饭",
         "isCompleted": true,
         "isEditing": false
       },
       {
         "id": 2,
         "title": "睡觉",
         "isCompleted": true,
         "isEditing": false
       },
       {
         "title": "打豆豆",
         "isCompleted": false,
         "isEditing": false,
         "id": 3
       }
     ],
      "posts": [
       {
         "id": 1,
         "title": "Hello React Query"
       },
       {
         "id": 2,
         "title": "React Query is Great"
       }
     ]
   }
   ```

3. 在 `package.json` 文件中添加命令

   ```json
   "scripts": {
       "json-server": "json-server --watch db.json --port 3001"
     }
   ```

4. 启动程序 `npm run json-server`

## 3. 全局配置

1. React Query 会在客户端的内存中缓存状态，任何组件都可以从缓存中获取状态
2. 组件可以通过 `queryClient` 对象操作内存中的缓存状态
3. 开发者需要在应用的入口文件中通过 `QueryClient` 类创建 `queryClient` 对象
4. 开发者需要通过 `QueryClientProvider` 组件将 `queryClient` 对象传递到下层组件
5. 组件通过 `useQueryClient` 钩子函数获取 `queryClient` 对象

```react
import ReactDOM from "react-dom"
import App from "./App"
import axios from "axios"
import { QueryClient, QueryClientProvider } from "react-query"

// 响应拦截器, 让开发者直接获取到服务器端返回的数据
axios.interceptors.response.use(response => response.data)
axios.defaults.baseURL = "http://localhost:3001"

// 创建 queryClient 对象
const queryClient = new QueryClient()

ReactDOM.render(
  {/* 将 queryClient 对象传递到下层组件 */}
  <QueryClientProvider client={queryClient}>
    <App />
  </QueryClientProvider>,
  document.getElementById("root")
)
```

## 4. useQuery 同步服务端状态

### 4.1 基本使用

在组件挂载完成后发送请求获取状态，缓存状态。

获取服务端默认待办事项列表。

```react
// TodosMain.js 同步服务端状态待办事项列表
import axios from "axios"
import { useQuery } from "react-query"
import TodoItem from "./TodoItem"

async function fetchTodos() {
  try {
    return axios.get("/todos")
  } catch (err) {
    throw new Error("服务端默认待办事项加载失败")
  }
}

function TodosMain() {
  // useQuery(queryKey, queryFn)
  const { isLoading, isError, error, data } = useQuery("todos", fetchTodos)
  if (isLoading) return <div>正在加载服务端默认待办事项</div>
  if (isError) return <div>{error.message}</div>
  return (
    <section className="main">
      <ul className="todo-list">
        {data.map(todo => <TodoItem key={todo.id} todo={todo} />)}
      </ul>
    </section>
  )
}

export default TodosMain
```

### 4.2 配置选项

#### 4.2.1 retry

在请求发生错误时，默认会重试 3 次，如果请求还是不成功 `isError` 为真。

可以通过 retry 配置项更改重试次数或者禁用重试 ( false )。

```react
useQuery("todos", fetchTodos, { retry: 2 })
```

#### 4.2.2 refetchOnWindowFocus

当浏览器窗口重新获取焦点时，重新向服务器端发送请求同步最新状态。

在状态未更新之前，组件中显示缓存状态。

可以通过 `refetchOnWindowFocus` 配置项禁用此行为。

```react
useQuery("todos", fetchTodos, { refetchOnWindowFocus: false })
```

#### 4.2.3 enabled

默认值为 true，即组件挂载完成后发送请求同步服务端状态。当值为 false 的时候此行为被禁止，当值被改为 true 时，发送请求同步服务端状态。

```react
const [isLoad, setIsLoad] = useState(false)
useQuery("todos", fetchTodos, { enabled: isLoad })
<button onClick={() => setIsLoad(true)}>同步状态</button>
data && data.map
```

#### 4.2.4 staleTime

状态的保质期。在同步状态时，如果状态仍然在保质期内，直接从缓存中获取状态，不会在后台发送真实的请求来更新状态缓存。

```react
useQuery("todos", fetchTodos, { staleTime: 5000 }) 
// 每次状态同步完成后都会有5秒的保质期
```

#### 4.2.5 placeholderData

在服务端状态没有加载完成前，可以使用占位符状态填充客户端缓存以提升用户体验。

```react
useQuery("todos", fetchTodos, { placeholderData: [ { id: 1, title: "吃饭" } ] })
```

#### 4.2.6 refetchInterval

指定轮询的间隔时间，false 为不轮询。

```react
useQuery("todos", fetchTodos, { refetchInterval: 1000 })
```

### 4.3 queryKey

useQuery 方法的第一个参数，除可以使用字符串以外，还可以使用数组，实现查询时传递参数。

实现查询 ID 为 1 的待办事项列表。

```react
import axios from "axios"
import { useQuery } from "react-query"

function getTodoById({ queryKey }) {
  try {
    return axios.get(`/todos/${queryKey[1]}`)
  } catch (err) {
    throw new Error("待办事项获取失败")
  }
}

function FetchTodoById() {
  const { data } = useQuery(["todo", 2], getTodoById)
  return (
    <div>
      <pre>{JSON.stringify(data, null, 2)}</pre>
    </div>
  )
}

export default FetchTodoById
```

```react
useQuery({ queryKey: ["todo", 2], queryFn: getTodoById })
```

## 5. useMutation 更改状态

修改状态，使用 useMutation 钩子函数，修改包括，删除，更新，添加。

实现添加待办事项。

```react
// TodosHeader.js 添加待办事项
import axios from "axios"
import { useState } from "react"
import { useMutation } from "react-query"

async function addTodo(todo) {
  try {
    return axios.post("/todos", todo)
  } catch (err) {
    throw new Error("任务添加失败")
  }
}

function TodosHeader() {
  const [title, setTitle] = useState("")
  const { mutate } = useMutation(addTodo, {
    onSuccess() {
      setTitle("")
    }
  })
  return (
    <header className="header">
      <input
        value={title}
        onChange={event => setTitle(event.target.value)}
        onKeyUp={event => {
          if (event.code === "Enter") {
            mutate({ title, isCompleted: false, isEditing: false })
          }
        }}
      />
    </header>
  )
}

export default TodosHeader
```

### 6.1 同步服务端缓存

实现在待办事项添加成功后更新客户端缓存以使组件展示出最新的待办事项列表。

```react
import { useQueryClient } from "react-query"
const queryClient = useQueryClient()

useMutation(addTodo, {
    onSuccess() {
      // 使本地缓存中的 todos 状态无效, 重新发送请求同步状态。
      queryClient.invalidateQueries("todos")
    }
})
```

### 6.2 操作客户端缓存

实现更改待办事项的是否已完成状态。

通过 setQueryData 方法可以手动设置客户端缓存数据。

```react
import axios from "axios"
import { useMutation, useQueryClient } from "react-query"

async function modifyTodoCompleted({ id, isCompleted }) {
  try {
    return axios.patch(`/todos/${id}`, { isCompleted })
  } catch (err) {
    throw new Error("任务状态更改失败")
  }
}

function TodoCompleted({ todo }) {
  const queryClient = useQueryClient()
  const { mutate } = useMutation(modifyTodoCompleted, {
    onSuccess(response) {
      queryClient.setQueryData("todos", data =>
        data.map(todo => (todo.id !== response.id ? todo : response))
      )
    }
  })
  return (
    <input
      className="toggle"
      type="checkbox"
      checked={todo.isCompleted}
      onChange={event => {
        mutate({ id: todo.id, isCompleted: event.target.checked })
      }}
    />
  )
}

export default TodoCompleted
```

## 7. useQuery 同步客户端状态

实现计算未完成待办事项的数量。

当客户端内存中的状态发生变化后，所有使用 useQuery 同步该状态的组件都会得到更新。

```react
// hooks/todos.js
// 1. 将同步服务端待办事项抽象成自定义钩子函数 useTodos
// 2. 分别在不同组件中调用钩子函数以获取待办事项列表
import { useQuery } from "react-query"
import axios from "axios"

async function fetchTodos() {
  try {
    return axios.get("/todos")
  } catch (err) {
    throw new Error("服务端默认待办事项加载失败")
  }
}

export function useTodos() {
  return useQuery("todos", fetchTodos)
}
```

```react
import { useTodos } from "../hooks/todos"

function UnCompletedTodoCount() {
  const { data } = useTodos()
  return (
    <span className="todo-count">
      <strong>{data && data.filter(todo => !todo.isCompleted).length}</strong>
      item left
    </span>
  )
}

export default UnCompletedTodoCount
```

## 8. QueryObserver 状态订阅

通过 QueryObserver 可实现在任意组件中订阅状态，实现全局状态共享。

```react
import { useQueryClient, QueryObserver } from "react-query"
import { useEffect, useState } from "react"

function UnCompletedTodoCount() {
  const queryClient = useQueryClient()
  const [todos, setTodos] = useState([])
  useEffect(() => {
    const todosObserver = new QueryObserver(queryClient, { queryKey: "todos" })
    const unsubscribe = todosObserver.subscribe(result => setTodos(result.data))
    return () => unsubscribe()
  }, [])
  return (
    <span className="todo-count">
      <strong>{todos && todos.filter(todo => !todo.isCompleted).length}</strong>{" "}
      item left
    </span>
  )
}

export default UnCompletedTodoCount
```

## 9. useQueries 并发同步状态

使用 useQueries 可以并行发送请求，所有结果得到以后返回给开发者。

实现并发加载待办事项列表和文章列表。

```react
import { useQueries } from "react-query"
import axios from "axios"

async function fetchTodos() {
  try {
    return axios.get("/todos")
  } catch (err) {
    throw new Error("服务端默认待办事项加载失败")
  }
}

async function fetchPosts() {
  try {
    return axios.get("/posts")
  } catch (err) {
    throw new Error("文章列表加载失败")
  }
}

function Parallel() {
  const results = useQueries([
    {
      queryKey: "anotherTodos",
      queryFn: fetchTodos
    },
    {
      queryKey: "posts",
      queryFn: fetchPosts
    }
  ])
  return (
    <div>
      <pre>{JSON.stringify(results, null, 2)}</pre>
    </div>
  )
}

export default Parallel
```

## 10. useInfiniteQuery 分页

使用它可以实现和分页相关的逻辑。

```react
import axios from "axios"
import { useInfiniteQuery } from "react-query"

async function fetchUser({ pageParam = 1 }) {
  try {
    return axios.get(`https://reqres.in/api/users?page=${pageParam}`)
  } catch (err) {
    throw new Error("用户状态同步失败")
  }
}

function LoadMore() {
  const {
    data,
    isLoading,
    isFetching,
    hasNextPage,
    fetchNextPage
  } = useInfiniteQuery("users", fetchUser, {
    getNextPageParam(current) {
      if (current.page < current.total_pages) {
        return current.page + 1
      }
    }
  })
  if (isLoading) return <div>用户状态正在加载中...</div>
  return (
    <div>
      <ul>
        {data.pages.map(page =>
          page.data.map(user => <li key={user.id}>{user.first_name}</li>)
        )}
      </ul>
      {hasNextPage && <button onClick={() => fetchNextPage()}>加载更多</button>}
      {isFetching && <div>更多状态加载中...</div>}
    </div>
  )
}

export default LoadMore
```

`isLoading` 只有初次加载时才会变为 true，通常用作首次加载数据时的加载状态。

`isFetching` 是只要发生加载行为就会变为 true，通过用作加载更多时的加载状态。

## 11. useIsFetching 全局加载状态

只要程序中有状态在同步，useIsFetching 钩子函数获取的结果就为 true，可以通过它实现全局加载状态的提示。

`yarn add react-spinners@0.10.6 @emotion/react@11.1.5`

```react
import { PacmanLoader } from "react-spinners"
import { useIsFetching } from "react-query"
import { css } from "@emotion/react"

const loaderCss = css`
  position: absolute;
  left: 100%;
  top: 0;
  transform: translateX(-400%);
  z-index: 1;
`

function GlobalLoading() {
  const isFetching = useIsFetching()
  return (
    <PacmanLoader
      loading={isFetching}
      color={"rgba(175, 47, 47, 0.25)"}
      size={15}
      css={loaderCss}
    />
  )
}

export default GlobalLoading
```

