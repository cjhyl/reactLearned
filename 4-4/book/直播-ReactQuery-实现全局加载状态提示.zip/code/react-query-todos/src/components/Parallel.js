import axios from "axios"
import { useQueries } from "react-query"

async function fetchTodos() {
  return axios.get("/todos")
}

async function fetchPosts() {
  return axios.get("/posts")
}

function Parallel() {
  const result = useQueries([
    { queryKey: "anthorTodos", queryFn: fetchTodos },
    { queryKey: "posts", queryFn: fetchPosts }
  ])
  return (
    <div>
      <pre>{JSON.stringify(result, null, 2)}</pre>
    </div>
  )
}

export default Parallel
