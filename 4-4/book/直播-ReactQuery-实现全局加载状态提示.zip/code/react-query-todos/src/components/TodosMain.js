import TodoItem from "./TodoItem"
import { useState } from "react"
import { useTodos } from "../hooks/todos"

function TodosMain() {
  const [isLoad, setIsLoad] = useState(false)
  const { isLoading, isError, error, data } = useTodos()
  if (isLoading) return <div>服务器端默认的待办事项正在加载中...</div>
  if (isError) return <div>{error.message}</div>
  return (
    <section className="main">
      <input className="toggle-all" type="checkbox" />
      <ul className="todo-list">
        {data && data.map(todo => <TodoItem key={todo.id} todo={todo} />)}
      </ul>
      {/* <button onClick={() => setIsLoad(true)}>获取状态</button> */}
    </section>
  )
}

export default TodosMain
