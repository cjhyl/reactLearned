// useBlockLayout
// 为 row, cell 添加固定宽度
// 将 row 的 display 设置为 flex
// 将 cell 的 display 设置为 inline-block
// 将 cell 的 box-sizing 设置 border-box
import { useBlockLayout, useTable } from "react-table"
import { useSticky } from "react-table-sticky"
import MOCK_DATA from "./MOCK_DATA.json"
import { COLUMNS } from "./Columns"
import { Styles } from "./TableStyles"
import { useMemo } from "react"

const StickyTable = () => {
  // 缓存列信息
  const columns = useMemo(() => COLUMNS, [])
  // 缓存表格数据
  const data = useMemo(() => MOCK_DATA, [])
  const { getTableProps, headerGroups, rows, getTableBodyProps, prepareRow } =
    useTable({ columns, data }, useBlockLayout, useSticky)
  return (
    <Styles>
      <div
        {...getTableProps()}
        className="table sticky"
        style={{ width: 1000, height: 500 }}
      >
        <div className="header">
          {headerGroups.map(headerGroup => (
            <div {...headerGroup.getHeaderGroupProps()} className="tr">
              {headerGroup.headers.map(column => (
                <div {...column.getHeaderProps()} className="th">
                  {column.render("Header")}
                </div>
              ))}
            </div>
          ))}
        </div>
        <div {...getTableBodyProps()} className="body">
          {rows.map(row => {
            prepareRow(row)
            return (
              <div {...row.getRowProps()} className="tr">
                {row.cells.map(cell => (
                  <div {...cell.getCellProps()} className="td">
                    {cell.render("Cell")}
                  </div>
                ))}
              </div>
            )
          })}
        </div>
      </div>
    </Styles>
  )
}

export default StickyTable
