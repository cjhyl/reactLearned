import { useQuery } from "react-query"
import axios from "axios"

async function fetchTodos() {
  try {
    return axios.get("/todos")
  } catch (err) {
    throw new Error("服务端默认待办事项加载失败")
  }
}

export function useTodos() {
  return useQuery("todos", fetchTodos)
}
