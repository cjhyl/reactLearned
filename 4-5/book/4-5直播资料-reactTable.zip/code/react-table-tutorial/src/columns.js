import dateFormat from "dateformat"
import ColumnFilter from "./ColumnFilter"

export const COLUMNS = [
  {
    Header: "ID",
    accessor: "id",
    Footer: "ID",
    disableFilters: true,
    sticky: "left"
  },
  {
    Header: "名",
    Footer: "名",
    accessor: "first_name",
    sticky: "left"
  },
  {
    Header: "姓",
    Footer: "姓",
    accessor: "last_name",
    sticky: "left"
  },
  {
    Header: "出生日期",
    Footer: "出生日期",
    accessor: "data_of_birth",
    Cell: ({ value }) => dateFormat(value, "yyyy-mm-dd")
  },
  {
    Header: "国家",
    Footer: "国家",
    accessor: "country"
  },
  {
    Header: "电话",
    Footer: "电话",
    accessor: "phone"
  },
  {
    Header: "邮件",
    Footer: "邮件",
    accessor: "email"
  },
  {
    Header: "年龄",
    Footer: "年龄",
    accessor: "age"
  }
]

export const COLUMNS_GROUP = [
  {
    Header: "ID",
    accessor: "id",
    Footer: "ID"
  },
  {
    Header: "姓名",
    Footer: "姓名",
    columns: [
      {
        Header: "名",
        Footer: "名",
        accessor: "first_name"
      },
      {
        Header: "姓",
        Footer: "姓",
        accessor: "last_name"
      }
    ]
  },
  {
    Header: "一般信息",
    Footer: "一般信息",
    columns: [
      {
        Header: "出生日期",
        Footer: "出生日期",
        accessor: "data_of_birth"
      },
      {
        Header: "国家",
        Footer: "国家",
        accessor: "country"
      },
      {
        Header: "电话",
        Footer: "电话",
        accessor: "phone"
      }
    ]
  }
]
