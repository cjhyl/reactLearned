// Checkbox.js
import { forwardRef } from "react"
// 将 indeterminate 从 props 单独解构出来, 它不能直接被添加到 input 身上
// ref: 因为 react-table 要为复选添加功能, 要对其进行操作, 所以通过 Ref 的方式获取该复选
// rest: 通过 props 的方式向复选框中添加属性以实现复选框的单选和全选功能
const Checkbox = forwardRef(({ indeterminate, ...rest }, ref) => {
  return <input type="checkbox" ref={ref} {...rest} />
})

export default Checkbox
