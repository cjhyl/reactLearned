module.exports = {
  plugins: ["react-hooks"],
  rules: {
    "react-hooks/exhaustive-deps": 0
  }
}
