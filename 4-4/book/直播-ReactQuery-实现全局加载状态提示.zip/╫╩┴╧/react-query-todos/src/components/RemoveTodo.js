import axios from "axios"
import { useMutation, useQueryClient } from "react-query"

async function removeTodoById(id) {
  try {
    return axios.delete(`/todos/${id}`)
  } catch (err) {
    throw new Error("任务删除失败")
  }
}

function RemoveTodo({ todo }) {
  const queryClient = useQueryClient()
  const { mutate } = useMutation(removeTodoById, {
    onSuccess() {
      queryClient.invalidateQueries("todos")
    }
  })
  return <button className="destroy" onClick={() => mutate(todo.id)} />
}

export default RemoveTodo
