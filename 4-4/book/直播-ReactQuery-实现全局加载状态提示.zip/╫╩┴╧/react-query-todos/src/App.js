import TodosContainer from "./components/TodosContainer"
import Parallel from "./components/Parallel"
import LoadMore from "./components/LoadMore"
import FetchTodoById from "./components/FetchTodoById"
import GlobalLoading from "./components/GlobalLoading"

function App() {
  return (
    <>
      <GlobalLoading />
      <TodosContainer />
      <hr />
      <FetchTodoById />
      <hr />
      <LoadMore />
      <hr />
      <Parallel />
    </>
  )
}

export default App
