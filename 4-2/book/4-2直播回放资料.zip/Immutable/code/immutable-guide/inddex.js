import { List } from "immutable"

const l1 = new List(["a", "b"])
const l2 = l1.set(0, "x")
console.log(l2) // List ["x","b"]
console.log(l1) // List ["a", "b"]
