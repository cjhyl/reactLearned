import axios from "axios"
import { useState } from "react"
import { useMutation, useQueryClient } from "react-query"

async function addTodo(todo) {
  try {
    return axios.post("/todos", todo)
  } catch (err) {
    throw new Error("任务添加失败")
  }
}

function TodosHeader() {
  const queryClient = useQueryClient()
  const [title, setTitle] = useState("")
  const { mutate } = useMutation(addTodo, {
    onSuccess() {
      queryClient.invalidateQueries("todos")
      setTitle("")
    }
  })
  return (
    <header className="header">
      <h1>todos</h1>
      <input
        className="new-todo"
        placeholder="What needs to be done?"
        autoFocus
        value={title}
        onChange={event => setTitle(event.target.value)}
        onKeyUp={event => {
          if (event.code === "Enter") {
            mutate({ title, isCompleted: false, isEditing: false })
          }
        }}
      />
    </header>
  )
}

export default TodosHeader
