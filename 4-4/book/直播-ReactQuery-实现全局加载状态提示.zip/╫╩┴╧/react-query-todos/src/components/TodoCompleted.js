import axios from "axios"
import { useMutation, useQueryClient } from "react-query"

async function modifyTodoCompleted({ id, isCompleted }) {
  try {
    return axios.patch(`/todos/${id}`, { isCompleted })
  } catch (err) {
    throw new Error("任务状态更改失败")
  }
}

function TodoCompleted({ todo }) {
  const queryClient = useQueryClient()
  const { mutate } = useMutation(modifyTodoCompleted, {
    onSuccess(response) {
      queryClient.setQueryData("todos", data =>
        data.map(todo => (todo.id !== response.id ? todo : response))
      )
    }
  })
  return (
    <input
      className="toggle"
      type="checkbox"
      checked={todo.isCompleted}
      onChange={event => {
        mutate({ id: todo.id, isCompleted: event.target.checked })
      }}
    />
  )
}

export default TodoCompleted
