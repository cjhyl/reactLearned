import { useQueries } from "react-query"
import axios from "axios"

async function fetchTodos() {
  try {
    return axios.get("/todos")
  } catch (err) {
    throw new Error("服务端默认待办事项加载失败")
  }
}

async function fetchPosts() {
  try {
    return axios.get("/posts")
  } catch (err) {
    throw new Error("文章列表加载失败")
  }
}

function Parallel() {
  const results = useQueries([
    {
      queryKey: "anotherTodos",
      queryFn: fetchTodos
    },
    {
      queryKey: "posts",
      queryFn: fetchPosts
    }
  ])
  return (
    <div>
      <pre>{JSON.stringify(results, null, 2)}</pre>
    </div>
  )
}

export default Parallel
