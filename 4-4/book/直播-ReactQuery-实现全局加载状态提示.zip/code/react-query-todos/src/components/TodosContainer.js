import TodosHeader from "./TodosHeader"
import TodosMain from "./TodosMain"
import TodosFooter from "./TodosFooter"

function TodosContainer() {
  return (
    <div className="todoapp">
      <TodosHeader />
      <TodosMain />
      <TodosFooter />
    </div>
  )
}

export default TodosContainer
