import MOCK_DADA from "./MOCK_DATA.json"
import { COLUMNS } from "./columns"
import { useTable, useRowSelect } from "react-table"
import { useMemo } from "react"
import "./table.css"
import Checkbox from "./Checkbox"

function RowSelection() {
  const data = useMemo(() => MOCK_DADA, [])
  const columns = useMemo(() => COLUMNS, [])
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    footerGroups,
    selectedFlatRows
  } = useTable(
    {
      columns,
      data
    },
    useRowSelect,
    hooks => {
      // 在初始化表格实例对象时调用
      // hooks: 对象, 钩子函数集合
      // 以编程方式向表格中添加列
      hooks.visibleColumns.push(columns => {
        // columns 现有的列数据
        return [
          {
            id: "selection",
            Header: ({ getToggleAllRowsSelectedProps }) => (
              // 实现全选功能
              <Checkbox {...getToggleAllRowsSelectedProps()} />
            ),
            // 实现单选功能
            Cell: ({ row }) => <Checkbox {...row.getToggleRowSelectedProps()} />
          },
          ...columns
        ]
      })
    }
  )
  return (
    <>
      <pre>
        {JSON.stringify(
          { selectedRows: selectedFlatRows.map(row => row.original) },
          null,
          2
        )}
      </pre>
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(header => (
                <th {...header.getHeaderProps()}>{header.render("Header")}</th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.map(row => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => (
                  <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                ))}
              </tr>
            )
          })}
        </tbody>
        <tfoot>
          {footerGroups.map(footerGroup => (
            <tr {...footerGroup.getFooterGroupProps()}>
              {footerGroup.headers.map(header => (
                <td {...header.getFooterProps()}>{header.render("Footer")}</td>
              ))}
            </tr>
          ))}
        </tfoot>
      </table>
    </>
  )
}

export default RowSelection
