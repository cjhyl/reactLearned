import Todos from "./Todos"

function App() {
  return <Todos />
}

export default App
