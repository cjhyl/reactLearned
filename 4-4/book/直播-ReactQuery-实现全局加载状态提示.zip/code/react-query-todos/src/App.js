import FetchTodoById from "./components/FetchTodoById"
import GlobalLoading from "./components/GlobalLoading"
import LoadMore from "./components/LoadMore"
import Parallel from "./components/Parallel"
import TodosContainer from "./components/TodosContainer"

function App() {
  return (
    <>
      <TodosContainer />
      <hr />
      <LoadMore />
      <hr />
      <FetchTodoById />
      <hr />
      <Parallel />
      <hr />
      <GlobalLoading />
    </>
  )
}

export default App
