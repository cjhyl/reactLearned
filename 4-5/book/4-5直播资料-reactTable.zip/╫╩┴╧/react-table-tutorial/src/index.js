import ReactDOM from "react-dom"
import StickyTable from "./StickyTable"

ReactDOM.render(<StickyTable />, document.getElementById("root"))
