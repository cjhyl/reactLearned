import axios from "axios"
import { useMutation, useQueryClient } from "react-query"
import { useState } from "react"

async function addTodo(todo) {
  return axios.post("/todos", todo)
}

function TodosHeader() {
  const queryClient = useQueryClient()
  const { mutate } = useMutation(addTodo, {
    onSuccess() {
      setTitle("")
      queryClient.invalidateQueries("todos")
    }
  })
  const [title, setTitle] = useState("")
  return (
    <header className="header">
      <h1>todos</h1>
      <input
        className="new-todo"
        placeholder="What needs to be done?"
        autoFocus
        value={title}
        onChange={event => setTitle(event.target.value)}
        onKeyUp={event => {
          if (event.code === "Enter") {
            mutate({ title, isCompleted: false, isEditing: false })
          }
        }}
      />
    </header>
  )
}

export default TodosHeader
