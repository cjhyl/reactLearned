import axios from "axios"
import { useQuery } from "react-query"

function getTodoById({ queryKey }) {
  try {
    return axios.get(`/todos/${queryKey[1]}`)
  } catch (err) {
    throw new Error("待办事项获取失败")
  }
}

function FetchTodoById() {
  // const { data } = useQuery(["todo", 2], getTodoById)
  const { data } = useQuery({ queryKey: ["todo", 2], queryFn: getTodoById })
  return (
    <div>
      <pre>{JSON.stringify(data, null, 2)}</pre>
    </div>
  )
}

export default FetchTodoById
