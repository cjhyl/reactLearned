import {
  createSlice,
  createAsyncThunk,
  createEntityAdapter,
  createSelector
} from "@reduxjs/toolkit"
import axios from "axios"

export const TODOS_FEATURE_KEY = "todos"

export const loadTodos = createAsyncThunk(
  "todos/loadTodos",
  payload =>
    axios.get(payload).then(response => response.data)
)

const todosAdapter = createEntityAdapter()

const { reducer: TodosReducer, actions } = createSlice({
  name: TODOS_FEATURE_KEY,
  initialState: todosAdapter.getInitialState(),
  reducers: {
    addTodo: todosAdapter.addOne,
    setTodos: todosAdapter.addMany
  },
  extraReducers: {
    [loadTodos.fulfilled]: todosAdapter.addMany
  }
})

const { selectAll } = todosAdapter.getSelectors()

export const selectTodosList = createSelector(
  state => state[TODOS_FEATURE_KEY],
  selectAll
)

export const { addTodo, setTodos } = actions
export default TodosReducer
