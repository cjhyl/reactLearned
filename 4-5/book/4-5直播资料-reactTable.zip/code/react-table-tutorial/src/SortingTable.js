import MOCK_DADA from "./MOCK_DATA.json"
import { COLUMNS } from "./columns"
import { useTable, useSortBy } from "react-table"
import { useMemo } from "react"
import "./table.css"

function SortingTable() {
  const data = useMemo(() => MOCK_DADA, [])
  const columns = useMemo(() => COLUMNS, [])
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    footerGroups
  } = useTable(
    {
      columns,
      data
    },
    useSortBy
  )
  return (
    <table {...getTableProps()}>
      <thead>
        {headerGroups.map(headerGroup => (
          <tr {...headerGroup.getHeaderGroupProps()}>
            {headerGroup.headers.map(header => (
              <th {...header.getHeaderProps(header.getSortByToggleProps())}>
                {header.render("Header")}
                <span>
                  {header.isSorted ? (header.isSortedDesc ? "↓" : "↑") : ""}
                </span>
              </th>
            ))}
          </tr>
        ))}
      </thead>
      <tbody {...getTableBodyProps()}>
        {rows.map(row => {
          prepareRow(row)
          return (
            <tr {...row.getRowProps()}>
              {row.cells.map(cell => (
                <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
              ))}
            </tr>
          )
        })}
      </tbody>
      <tfoot>
        {footerGroups.map(footerGroup => (
          <tr {...footerGroup.getFooterGroupProps()}>
            {footerGroup.headers.map(header => (
              <td {...header.getFooterProps()}>{header.render("Footer")}</td>
            ))}
          </tr>
        ))}
      </tfoot>
    </table>
  )
}

export default SortingTable
