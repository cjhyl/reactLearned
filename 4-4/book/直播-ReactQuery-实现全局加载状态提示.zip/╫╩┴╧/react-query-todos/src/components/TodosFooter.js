import UnCompletedTodoCount from "./UnCompletedTodoCount"

function TodosFooter() {
  return (
    <footer className="footer">
      <UnCompletedTodoCount />
      <ul className="filters">
        <li>
          <button className="selected">All</button>
        </li>
        <li>
          <button>Active</button>
        </li>
        <li>
          <button>Completed</button>
        </li>
      </ul>
      <button className="clear-completed">Clear completed</button>
    </footer>
  )
}

export default TodosFooter
