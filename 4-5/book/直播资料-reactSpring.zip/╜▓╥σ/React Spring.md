## React Spring

[官网](https://react-spring.io/)

<img src="./images/12.png" />

`yarn add react-spring@9.2.1 styled-components@5.3.0`

```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.2/css/bulma.min.css" />
```

### 1. useSpring

<img src="./images/01.gif" align="left"/>

```react
import { useSpring, animated } from "react-spring"

function App() {
  const animation = useSpring({
    from: { left: 0, backgroundColor: "pink" },
    to: { left: 500, backgroundColor: "skyblue" },
    delay: 1000
  })
  return (
    <animated.div
      style={{
        ...animation,
        width: 100,
        height: 100,
        position: "absolute",
        top: 0
      }}
    ></animated.div>
  )
}

export default App
```

<img src="./images/02.gif" align="left"/>

```react
import { useState } from "react"
import { useSpring, animated } from "react-spring"

function App() {
  const [on, setOn] = useState(false)
  const animation = useSpring({
    from: { left: 0, backgroundColor: "pink" },
    to: { left: 500, backgroundColor: "skyblue" },
    delay: 1000,
    reverse: on,
    onRest: () => setOn(!on)
  })
  return (
    <animated.div
      style={{
        ...animation,
        width: 100,
        height: 100,
        position: "absolute",
        top: 10
      }}
    ></animated.div>
  )
}

export default App
```

<img src="./images/03.gif" align="left"/>

```react
import { useState } from "react"
import { useSpring, animated } from "react-spring"

function App() {
  const [on, setOn] = useState(false)
  const animation = useSpring({
    left: on ? 500 : 0,
    backgroundColor: on ? "skyblue" : "pink"
  })
  return (
    <animated.div
      style={{
        ...animation,
        width: 100,
        height: 100,
        position: "absolute",
        top: 10
      }}
      onClick={() => setOn(!on)}
    ></animated.div>
  )
}

export default App
```

<img src="./images/04.gif" align="left"/>

```react
import { useSpring, animated } from "react-spring"

function App() {
  const { number } = useSpring({
    from: { number: 0 },
    to: { number: 100 },
    config: {
      duration: 2000
    }
  })
  return <animated.div>{number.to(n => n.toFixed(2))}</animated.div>
}

export default App
```

<img src="./images/05.gif" align="left"/>

```react
import styled from "styled-components"
import { useSpring, animated } from "react-spring"
import { useRef } from "react"

const data = [
  "Cras justo odio",
  "Dapibus ac facilisis in",
  "Morbi leo risus",
  "Porta ac consectetur ac",
  "Vestibulum at eros",
  "List group item heading",
  "Something else here",
  "Separated link",
  "Another action",
  "Extra small button",
  "Signed in as Mark Otto",
  "This is a simple hero unit"
]

const Container = styled(animated.div)`
  width: 240px;
  height: 100px;
  overflow: auto;
  background-color: skyblue;
  margin: 20px 0 10px 16px;
  padding: 0 10px;
  color: #fff;
  & > div {
    height: 30px;
    line-height: 30px;
  }
`

function App() {
  const ref = useRef(null)
  const { scroll } = useSpring({
    scroll: ref?.current?.scrollTop || 0
  })
  return (
    <>
      <Container ref={ref} scrollTop={scroll}>
        {data.map(item => (
          <div key={item}>{item}</div>
        ))}
      </Container>
      <button
        className="button is-info ml-4"
        onClick={() =>
          scroll.start({
            from: { scroll: ref.current.scrollTop },
            to: { scroll: 0 }
          })
        }
      >
        scrollToTop
      </button>
    </>
  )
}

export default App
```

### 2. useSprings

创建多元素动画。

<img src="./images/06.gif"/>

```react
import { useState } from "react"
import { animated, useSprings } from "react-spring"

const data = ["primary", "success", "danger", "warning"]

function App() {
  const [on, setOn] = useState(false)
  const animations = useSprings(
    data.length,
    data.map((item, index) => {
      return {
        from: {
          transform: `translateX(${index % 2 === 0 ? -110 : 110}%)`
        },
        to: {
          transform: "translateX(0%)"
        },
        reverse: on
      }
    })
  )
  return (
    <div className="container">
      <button
        onClick={() => setOn(!on)}
        className="button mt-2 is-fullwidth is-info"
      >
        Click
      </button>
      <ul>
        {data.map((item, index) => (
          <animated.li style={animations[index]} key={item}>
            <button className={`button mt-2 is-fullwidth is-${item}`}>
              {item}
            </button>
          </animated.li>
        ))}
      </ul>
    </div>
  )
}

export default App
```

### 3. useTrail

创建交错动画，先创建动画，根据动画创建执行动画的元素。

<img src="./images/07.gif" align="left"/>

```react
import { useState } from "react"
import { useTrail, animated, config } from "react-spring"
import data from "./MOCK_DATA.json"

function App() {
  const [{ dataToShow, indexStartRender }, setState] = useState({
    dataToShow: data,
    indexStartRender: 0
  })
  const trail = useTrail(dataToShow.length, {
    from: {
      transform: "translateY(100%)"
    },
    to: {
      transform: "translateY(0%)"
    },
    reset: true,
    config: config.wobbly
  })
  const onClickHandler = index => {
    const newData = [
      ...dataToShow.slice(0, index),
      ...dataToShow.slice(index + 1)
    ]
    setState({
      dataToShow: newData,
      indexStartRender: index
    })
  }
  return (
    <div className="container">
      {trail.map((item, index) => {
        return (
          <animated.button
            key={index}
            className="button is-fullwidth is-primary mt-2"
            style={index > indexStartRender ? item : null}
            onClick={() => onClickHandler(index)}
          >
            {dataToShow[index].first_name} {dataToShow[index].last_name}
          </animated.button>
        )
      })}
    </div>
  )
}

export default App
```

### 4. useTransition

创建入场动画和出场动画，可以是一个元素也可以是一组元素。

<img src="./images/08.gif" align="left" width="40%"/>

```react
<div className="app">
  <button>button</button>
  <div className="container">
    <div className="item">item</div>
  </div>
</div>
```

```react
import { useState } from "react"
import { animated, useTransition } from "react-spring"
import "./App.css"

function App() {
  const [isVisible, setIsVisible] = useState(false)
  const transition = useTransition(isVisible, {
    from: {
      opacity: 0,
      x: -300,
      y: 800
    },
    enter: {
      opacity: 1,
      x: 0,
      y: 0
    },
    leave: {
      opacity: 0,
      x: 300,
      y: 800
    }
  })
  return (
    <div className="app">
      <button onClick={() => setIsVisible(!isVisible)}>
       	{isVisible ? "卸载" : "挂载"}
      </button>
      <div className="container">
        {transition((style, item) => {
          return item ? (
            <animated.button className="item" style={style}></animated.button>
          ) : null
        })}
      </div>
    </div>
  )
}

export default App
```

<img src="./images/09.gif" align="left" width="40%"/>

```react
import { useState } from "react"
import { animated, useTransition } from "react-spring"
import "./App.css"

function App() {
  const [items, setItems] = useState([])
  const transition = useTransition(items, {
    from: {
      opacity: 0,
      x: -300,
      y: 800
    },
    enter: item => ({ opacity: 1, x: 0, y: item.y, delay: item.delay }),
    leave: {
      opacity: 0,
      x: 300,
      y: 800
    }
  })
  const onClickHandler = () => {
    setItems(prev =>
      prev.length
        ? []
        : [
            { y: -50, delay: 200 },
            { y: 0, delay: 400 },
            { y: 50, delay: 600 }
          ]
    )
  }
  return (
    <div className="app">
      <button onClick={onClickHandler}>{items.length ? "卸载" : "挂载"}</button>
      <div className="container">
        {transition((style, item) => {
          return item ? (
            <animated.div className="item" style={style}></animated.div>
          ) : null
        })}
      </div>
    </div>
  )
}

export default App
```

<img src="./images/10.gif" align="left" width="40%"/>

```react
import { useState } from "react"
import { animated, useTransition } from "react-spring"
import "./App.css"

function App() {
  const [items, setItems] = useState([])
  const transition = useTransition(items, {
    from: {
      opacity: 0,
      x: -300,
      y: 800,
      width: 20,
      height: 20
    },
    enter: item => async next => {
      await next({ opacity: 1, y: item.y, delay: item.delay })
      await next({
        x: 0,
        width: 100,
        height: 100
      })
    },
    leave: {
      opacity: 0,
      x: 300,
      y: 800
    }
  })
  return (
    <div className="app">
      <button
        onClick={() =>
          setItems(prev => {
            return prev.length
              ? []
              : [
                  { y: -50, delay: 200 },
                  { y: 0, delay: 400 },
                  { y: 50, delay: 600 }
                ]
          })
        }
      >
        {items.length ? "un-mount" : "mount"}
      </button>
      <div className="container">
        {transition((style, item) => {
          return item ? (
            <animated.div className="item" style={style}></animated.div>
          ) : null
        })}
      </div>
    </div>
  )
}

export default App
```

### 5. Carousel

<img src="./images/11.gif" align="left"/>

```react
import styled from "styled-components"
import { Children, useEffect, useRef, useState } from "react"
import { useSpring, animated } from "react-spring"

const Container = styled.div`
  width: 520px;
  margin: 30px auto 0 auto;
`

const Wrapper = styled.div`
  width: 520px;
  height: 280px;
  overflow: hidden;
  position: relative;
  margin-bottom: 10px;
`

const SlidesUl = styled(animated.ul)`
  width: ${props => props.width}px;
  height: 280px;
  position: absolute;
  left: 0;
  top: 0;
`

const Item = styled.li`
  width: 520px;
  height: 280px;
  float: left;
`

function Carousel({ children }) {
  const count = Children.count(children)
  const [index, setIndex] = useState(0)
  const timer = useRef(null)
  const scroll =
    (flag = 1) =>
    () => {
      setIndex(prev => {
        let target = prev + flag
        if (target > count - 1) return 0
        if (target < 0) return count - 1
        return target
      })
    }

  const animation = useSpring({
    from: { left: 0 }
  })

  const start = () => {
    timer.current = setInterval(scroll(), 2000)
  }

  const stop = () => clearInterval(timer.current)

  useEffect(start, [])

  useEffect(() => {
    animation.left.start({ to: { left: -index * 520 } })
  }, [index])
  return (
    <Container onMouseEnter={stop} onMouseLeave={start}>
      <Wrapper>
        <SlidesUl style={animation} width={count * 520}>
          {Children.map(children, child => (
            <Item>{child}</Item>
          ))}
          <Item></Item>
        </SlidesUl>
      </Wrapper>
      <button onClick={scroll(-1)} className="button mr-2">
        Prev
      </button>
      <button onClick={scroll()} className="button">
        next
      </button>
    </Container>
  )
}

export default Carousel
```

