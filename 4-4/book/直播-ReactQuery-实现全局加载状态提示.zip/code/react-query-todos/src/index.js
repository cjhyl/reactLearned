import ReactDOM from "react-dom"
import App from "./App"
import { QueryClient, QueryClientProvider } from "react-query"
import axios from "axios"
import "./index.css"

axios.interceptors.response.use(response => response.data)
axios.defaults.baseURL = "http://localhost:3001"

// 创建 queryClient 对象
const queryClient = new QueryClient()

ReactDOM.render(
  <QueryClientProvider client={queryClient}>
    <App />
  </QueryClientProvider>,
  document.getElementById("root")
)
