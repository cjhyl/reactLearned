import axios from "axios"
import { useMutation, useQueryClient } from "react-query"

function modifyTodoCompleted({ id, isCompleted }) {
  return axios.patch(`/todos/${id}`, { isCompleted })
}

function TodoCompleted({ todo }) {
  const queryClient = useQueryClient()
  const { mutate } = useMutation(modifyTodoCompleted, {
    onSuccess(response) {
      queryClient.setQueryData("todos", data =>
        data.map(todo => (todo.id !== response.id ? todo : response))
      )
    }
  })
  return (
    <input
      checked={todo.isCompleted}
      onChange={event =>
        mutate({ id: todo.id, isCompleted: event.target.checked })
      }
      className="toggle"
      type="checkbox"
    />
  )
}

export default TodoCompleted
