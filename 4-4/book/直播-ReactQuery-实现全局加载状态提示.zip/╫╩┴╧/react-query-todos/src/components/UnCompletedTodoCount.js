// import { useTodos } from "../hooks/todos"
import { useQueryClient, QueryObserver } from "react-query"
import { useEffect, useState } from "react"

function UnCompletedTodoCount() {
  // const { data } = useTodos()
  const queryClient = useQueryClient()
  const [todos, setTodos] = useState([])
  useEffect(() => {
    const todosObserver = new QueryObserver(queryClient, { queryKey: "todos" })
    const unsubscribe = todosObserver.subscribe(result => setTodos(result.data))
    return () => unsubscribe()
  }, [])
  return (
    <span className="todo-count">
      <strong>{todos && todos.filter(todo => !todo.isCompleted).length}</strong>{" "}
      item left
    </span>
  )
}

export default UnCompletedTodoCount
