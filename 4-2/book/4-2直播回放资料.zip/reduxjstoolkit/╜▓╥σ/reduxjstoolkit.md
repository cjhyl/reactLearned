## @reduxjs/toolkit

### 1. 快速入门 

简化 Redux 中样板代码流程代码的编写，对 Redux 进行的二次封装，使 Redux 的使用变得简单。

 [文档](https://redux-toolkit.js.org/)

1. 下载

   现有应用：`npm install @reduxjs/toolkit react-redux`

   新建应用：`create-react-app react-redux-toolkit --template redux`

2. 创建 Reducer、Action

   ```react
   // src/store/todos.js
   import { createSlice } from "@reduxjs/toolkit"
   
   export const TODOS_FEATURE_KEY = "todos"
   
   const { reducer: TodosReducer, actions } = createSlice({
     name: TODOS_FEATURE_KEY,
     initialState: [],
     reducers: {
       addTodo: (state, action) => {
         state.push(action.payload)
       }
     }
   })
   
   export const { addTodo } = actions
   export default TodosReducer
   ```


3. 创建 Store

   ```react
   // src/store/index.js
   import { configureStore } from "@reduxjs/toolkit"
   import TodosReducer, { TODOS_FEATURE_KEY } from "./todos"
   
   export default configureStore({
     reducer: {
       [TODOS_FEATURE_KEY]: TodosReducer
     },
     devTools: process.env.NODE_ENV !== "production"
   })
   ```

4. 配置 Provider

   ```react
   // src/index.js
   import ReactDOM from "react-dom"
   import App from "./App"
   import { Provider } from "react-redux"
   import store from "./store"
   
   ReactDOM.render(
     <Provider store={store}>
       <App />
     </Provider>,
     document.getElementById("root")
   )
   ```

5. 组件应用状态

   ```react
   // src/Todos.js
   import {
     addTodo,
     TODOS_FEATURE_KEY
   } from "./store/todos"
   import { useDispatch, useSelector } from "react-redux"
   
   function Todos() {
     const dispatch = useDispatch()
     const todos = useSelector(
       state => state[TODOS_FEATURE_KEY]
     )
     return (
       <div>
         <button
           onClick={() =>
             dispatch(addTodo({ title: "测试任务" }))
           }
         >
           添加任务
         </button>
         <ul>
           {todos.map((todo, index) => (
             <li key={index}>{todo.title}</li>
           ))}
         </ul>
       </div>
     )
   }
   
   export default Todos
   ```

### 2. 执行异步操作

#### 2.1 方式一

```react
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit"
import axios from "axios"

// 创建执行异步操作的 Action
export const loadTodos = createAsyncThunk(
  "todos/loadTodos",
  (payload, thunkAPI) => {
    axios
      .get(payload)
      .then(response => thunkAPI.dispatch(setTodos(response.data)))
  }
)

const { reducer: TodosReducer, actions } = createSlice({
  reducers: {
    setTodos: (state, action) => {
      action.payload.forEach(todo => state.push(todo))
    }
  }
})
```

```react
function Todos() {
  const dispatch = useDispatch()
  useEffect(() => {
    dispatch(loadTodos("https://jsonplaceholder.typicode.com/todos"))
  }, [])
}
```

#### 2.1 方式二

```react
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit"
import axios from "axios"

export const loadTodos = createAsyncThunk("todos/loadTodos", payload => {
  return axios.get(payload).then(response => response.data)
})

const { reducer: TodosReducer, actions } = createSlice({
  // 接收执行异步操作的 Action
  extraReducers: {
    // pending
    // rejected
    // fulfilled
    [loadTodos.fulfilled]: (state, action) => {
      action.payload.forEach(todo => state.push(todo))
    }
  }
})
```

### 3. 配置中间件

`npm i redux-logger`

```react
import { configureStore, getDefaultMiddleware } from "@reduxjs/toolkit"
import logger from "redux-logger"

export default configureStore({
  middleware: [...getDefaultMiddleware(), logger]
})
```

[redux-immutable-state-invariant](https://github.com/leoasis/redux-immutable-state-invariant) 

[redux-thunk](https://www.npmjs.com/package/redux-thunk)

### 4. 实体适配器

将状态放入实体适配器，实体适配器提供操作状态的各种方法，简化操作，提高性能。

```react
import { createEntityAdapter } from "@reduxjs/toolkit"

const todosAdapter = createEntityAdapter()

const { reducer: TodosReducer, actions } = createSlice({
  initialState: todosAdapter.getInitialState(),
  reducers: {
    addTodo: (state, action) => {
      todosAdapter.addOne(state, action.payload)
    }
  },
  extraReducers: {
    [loadTodos.fulfilled]: (state, action) => {
      todosAdapter.addMany(state, action.payload)
    }
  }
})
```

```react
import { addTodo, loadTodos } from "./store/todos"
import { useSelector } from "react-redux"

function Todos() {
  const todos = useSelector(
    state => state.todos.entities
  )
  return (
    <div>
      <button
        onClick={() =>
          dispatch(
            addTodo({
              title: "测试任务",
              id: Math.random()
            })
          )
        }
      >
        添加任务
      </button>
      {Object.values(todos).map((todo, index) => (
        <li key={index}>{todo.title}</li>
      ))}
    </div>
  )
}

export default Todos
```

```react
reducers: {
  addTodo: todosAdapter.addOne
},
extraReducers: {
  [loadTodos.fulfilled]: todosAdapter.addMany
}
```

### 5. 状态选择器

主要目的是简化组件中获取状态的代码。

```javascript
import { createSelector } from "@reduxjs/toolkit"

const { selectAll } = todosAdapter.getSelectors()

export const selectTodosList = createSelector(
  state => state[TODOS_FEATURE_KEY],
  selectAll
)
```

```react
import { selectTodosList } from "./store/todos"

function Todos() {
 const todos = useSelector(selectTodosList)
}
```

