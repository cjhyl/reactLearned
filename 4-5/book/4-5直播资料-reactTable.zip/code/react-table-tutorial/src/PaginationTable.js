import MOCK_DADA from "./MOCK_DATA.json"
import { COLUMNS } from "./columns"
import { useTable, usePagination } from "react-table"
import { useMemo } from "react"
import "./table.css"

function PaginationTable() {
  const data = useMemo(() => MOCK_DADA, [])
  const columns = useMemo(() => COLUMNS, [])
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    prepareRow,
    footerGroups,
    page,
    nextPage,
    previousPage,
    canNextPage,
    canPreviousPage,
    pageCount,
    state,
    gotoPage,
    setPageSize
  } = useTable(
    {
      columns,
      data,
      initialState: { pageIndex: 0, pageSize: 25 }
    },
    usePagination
  )
  const { pageIndex, pageSize } = state
  return (
    <>
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(header => (
                <th {...header.getHeaderProps()}>{header.render("Header")}</th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {page.map(row => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => (
                  <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                ))}
              </tr>
            )
          })}
        </tbody>
        <tfoot>
          {footerGroups.map(footerGroup => (
            <tr {...footerGroup.getFooterGroupProps()}>
              {footerGroup.headers.map(header => (
                <td {...header.getFooterProps()}>{header.render("Footer")}</td>
              ))}
            </tr>
          ))}
        </tfoot>
      </table>
      <div>
        <span>
          {pageIndex + 1}/{pageCount}
          <select
            value={pageSize}
            onChange={e => setPageSize(Number(e.target.value))}
          >
            {[10, 25, 50].map(pagesize => (
              <option key={pagesize} value={pagesize}>
                显示 {pagesize} 条数据
              </option>
            ))}
          </select>
          <button disabled={!canPreviousPage} onClick={() => gotoPage(0)}>
            第一页
          </button>
          <button disabled={!canPreviousPage} onClick={previousPage}>
            上一页
          </button>
          <button disabled={!canNextPage} onClick={nextPage}>
            下一页
          </button>
          <button
            disabled={!canNextPage}
            onClick={() => gotoPage(pageCount - 1)}
          >
            最后一页
          </button>
        </span>
      </div>
    </>
  )
}

export default PaginationTable
