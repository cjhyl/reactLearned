import { useState } from "react"
import { useAsyncDebounce } from "react-table"

function GlobalFilter({ setFilter }) {
  const [value, setValue] = useState("")
  const change = useAsyncDebounce(() => setFilter(value), 1000)
  return (
    <input
      type="text"
      onChange={e => {
        setValue(e.target.value)
        change()
      }}
    />
  )
}

export default GlobalFilter
