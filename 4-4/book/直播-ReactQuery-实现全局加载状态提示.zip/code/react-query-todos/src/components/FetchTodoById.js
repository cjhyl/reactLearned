import axios from "axios"
import { useQuery } from "react-query"

function getTodoById({ queryKey }) {
  return axios.get(`/todos/${queryKey[1]}`)
}

function FetchTodoById() {
  // todos => ["todos"]
  const { data } = useQuery(["todo", 2], getTodoById)
  return (
    <div>
      <pre>{JSON.stringify(data, null, 2)}</pre>
    </div>
  )
}

export default FetchTodoById
