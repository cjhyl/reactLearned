import { useState } from "react"
import { useAsyncDebounce } from "react-table"

function GlobalFilter({ setFilter }) {
  const [value, setValue] = useState("")
  const change = useAsyncDebounce(() => setFilter(value), 1000)
  return (
    <div>
      <input
        type="text"
        value={value}
        onChange={e => {
          setValue(e.target.value)
          change()
        }}
      />
    </div>
  )
}

export default GlobalFilter
