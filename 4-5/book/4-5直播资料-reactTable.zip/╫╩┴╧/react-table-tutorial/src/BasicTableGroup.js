// BasicTable.js
import { useTable } from "react-table"
import { COLUMNS_GROUP } from "./Columns"
import MOCK_DATA from "./MOCK_DATA.json"
import { useMemo } from "react"
import "./table.css"

function BasicTableGroup() {
  // 缓存列信息
  const columns = useMemo(() => COLUMNS_GROUP, [])
  // 缓存表格数据
  const data = useMemo(() => MOCK_DATA, [])
  // 创建表格实例对象
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    footerGroups
  } = useTable({
    columns,
    data
  })
  console.log(footerGroups)
  return (
    <>
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(header => (
                <th {...header.getHeaderProps()}>{header.render("Header")}</th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.map(row => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => (
                  <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                ))}
              </tr>
            )
          })}
        </tbody>
        <tfoot>
          {footerGroups.map(footerGroup => (
            <tr {...footerGroup.getFooterGroupProps()}>
              {footerGroup.headers.map(header => (
                <th {...header.getHeaderProps()}>{header.render("Footer")}</th>
              ))}
            </tr>
          ))}
        </tfoot>
      </table>
    </>
  )
}

export default BasicTableGroup
